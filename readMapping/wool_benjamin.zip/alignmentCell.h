enum Direction
{
    SUB,
    INS,
    DEL,
};

struct tableCell
{
    int sub;
    int del;
    int ins;
};
